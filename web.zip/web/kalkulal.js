function szamol() {
    var letszam = 1;
    var ejszaka = 1;
    var orszag = 'b';
    var fizetendo;

    //--számolás--
      
    //------------
    document.getElementById('eredmeny').value = fizetendo+" Ft";
    
}